import { defineStore } from 'pinia'
import { ref } from 'vue'
import { ApiService, type Conversation, type Message } from '../services/api'

export const useConversationStore = defineStore('conversation', () => {
  const currentConversationId = ref<number | null>(null)
  const isNewConversation = ref(true)
  const conversations = ref<Conversation[]>([])
  const currentMessages = ref<Message[]>([])

  // 创建新会话
  const createNewConversation = async () => {
    try {
      currentConversationId.value = await ApiService.createConversation()
      isNewConversation.value = false
      // 刷新会话列表
      await loadUserConversations()
      return currentConversationId.value
    } catch (error) {
      console.error('Failed to create conversation:', error)
      throw error
    }
  }

  // 加载用户的所有会话
  const loadUserConversations = async () => {
    try {
      const userId = localStorage.getItem('user_id')
      if (!userId) throw new Error('No user ID found')
      conversations.value = await ApiService.getUserConversations(userId)
    } catch (error) {
      console.error('Failed to load conversations:', error)
      throw error
    }
  }

  // 加载特定会话的消息
  const loadConversationMessages = async (conversationId: number) => {
    try {
      currentConversationId.value = conversationId
      isNewConversation.value = false
      currentMessages.value = await ApiService.getConversationMessages(conversationId)
    } catch (error) {
      console.error('Failed to load messages:', error)
      throw error
    }
  }

  // 重置会话状态
  const resetConversation = () => {
    currentConversationId.value = null
    isNewConversation.value = true
    currentMessages.value = []
  }

  return {
    currentConversationId,
    isNewConversation,
    conversations,
    currentMessages,
    createNewConversation,
    loadUserConversations,
    loadConversationMessages,
    resetConversation
  }
}) 