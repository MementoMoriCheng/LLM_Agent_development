# -*- coding: utf-8 -*-

def calculate(what):
    return eval(what)


if __name__ == '__main__':
    print(calculate("120 * 0.9"))
